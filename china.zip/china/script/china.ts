import AbstractModule, { Module } from "../../../../framework/abstract/mvvm/AbstractModule";
import { IGameCfg } from "../../../../framework/global/GameCfg";
import { ISceneEnterParams } from "../../../../framework/global/interfaces";
import { alias } from "../../../../script/launch/alias";
const { ccclass, property } = cc._decorator;
@ccclass
@Module("china")
export default class china extends AbstractModule {
    protected onShouldInit(): void {
        this.notify.on("scene", "enter", this.enter, this)
    }
    protected onRelease(): void {
    }
    enter(data: ISceneEnterParams) {
        this.notify.emitModule('common', 'waiting', 'show', "进入游戏中")
        let loadData = {
            module: this.moduleName,
            scene: (data.gameCfg.sceneName || data.gameCfg.name)+"_001",//(alias.isAliasing?"_001":""),
            logo: null,
            cfg: data.gameCfg,
            changeLanguage: data.changeLanguage,
            background: null//background,
        }
        if (data.gameCfg.loadLogo) {
            this.bundle.load(cc.path.join(this.skinPath, `textures/${data.gameCfg.loadLogo}`), cc.SpriteFrame).then((logo: cc.SpriteFrame) => {
                // loadData.logo = logo
                this.notify.emitModule('common', 'waiting', 'close')
                this.notify.emitModule('common', 'loading', 'over', loadData)
            }).catch((err) => {
                console.error(err)
                this.notify.emitModule('common', 'waiting', 'close')
            })
        } else {
            this.notify.emitModule('common', 'waiting', 'close')
            this.notify.emitModule('common', 'loading', 'over', loadData)
        }
    }
}
